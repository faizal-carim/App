﻿using System.Data.Entity;

namespace HandCTest.Models
{
    public class Club
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Stadium { get; set; }
        public double Capacity { get; set; }
        public string NickName { get; set; }
    }

    public class ClubDBContext : DbContext
    {
        public DbSet<Club> Movies { get; set; }
    }
}