﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(HandCTest.Startup))]
namespace HandCTest
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
